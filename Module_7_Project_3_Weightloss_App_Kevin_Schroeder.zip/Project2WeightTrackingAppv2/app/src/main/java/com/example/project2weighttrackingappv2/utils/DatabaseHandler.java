package com.example.project2weighttrackingappv2.utils;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.project2weighttrackingappv2.model.User;
import com.example.project2weighttrackingappv2.model.WeightLog;

import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class DatabaseHandler extends SQLiteOpenHelper {

    private static final int VERSION = 1;
    private static final String NAME = "weightLogListDatabase";

    // weight log table
    private static final String WEIGHT_LOG_TABLE = "weightLog";
    private static final String ID = "id";
    private static final String USER_ID = "user_id";
    private static final String DAILY_WEIGHT = "daily_weight";
    private static final String DATE = "date";
    private static final String CREATE_WEIGHT_LOG_TABLE = "CREATE TABLE " + WEIGHT_LOG_TABLE + "(" + ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + DAILY_WEIGHT + " INTEGER, " + USER_ID + " INTEGER, " + DATE + " TEXT)";

    // user table
    private static final String USER_TABLE = "users";
    private static final String FIRST_NAME = "first_name";
    private static final String LAST_NAME = "last_name";
    private static final String GOAL_WEIGHT = "goal_weight";
    private static final String EMAIL = "email";
    private static final String PASSWORD = "password";
    private static final String PHONE_NUMBER = "phone_number";
    private static final String NOTIFICATIONS = "notifications";
    private static final String CREATE_USERS_TABLE = "CREATE TABLE " + USER_TABLE + "(" + ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + FIRST_NAME + " TEXT, " + LAST_NAME + " TEXT, " +  PHONE_NUMBER + " TEXT, " + GOAL_WEIGHT + " INTEGER, " + PASSWORD + " TEXT, " + EMAIL + " TEXT, " + NOTIFICATIONS + " INTEGER)";

    private SQLiteDatabase db;
    public DatabaseHandler(Context context) {
        super(context, NAME, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_WEIGHT_LOG_TABLE);
        db.execSQL(CREATE_USERS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // drop the existing tables
        db.execSQL("DROP TABLE IF EXISTS " + WEIGHT_LOG_TABLE);
        db.execSQL("DROP TABLE IF EXISTS " + USER_TABLE);
        // create tables
        onCreate(db);
    }

    public void openDatabase() {
        db = this.getWritableDatabase();
    }

    public int getUserIdByEmail(String email) {
        try {
            Cursor cursor = db.rawQuery("SELECT id FROM " + USER_TABLE + " WHERE EMAIL = ?", new String[] {email});
            cursor.moveToFirst();
            return cursor.getInt(0);
        } catch (Exception e) {
            return 0;
        }
    }

    public String getUserNameByID(int id) {
        try {
            Cursor cursor = db.rawQuery("SELECT first_name FROM " + USER_TABLE + " WHERE ID = ?", new String[] {String.valueOf(id)});
            cursor.moveToFirst();
            return cursor.getString(0);
        } catch (Exception e) {
            return "";
        }
    }

    public int getNotificationsByID(int id) {
        try {
            Cursor cursor = db.rawQuery("SELECT notifications FROM " + USER_TABLE + " WHERE ID = ?", new String[] {String.valueOf(id)});
            cursor.moveToFirst();
            return cursor.getInt(0);
        } catch (Exception e) {
            return 0;
        }
    }

    public int getGoalWeightByID(int id) {
        try {
            Cursor cursor = db.rawQuery("SELECT goal_weight FROM " + USER_TABLE + " WHERE ID = ?", new String[] {String.valueOf(id)});
            cursor.moveToFirst();
            return cursor.getInt(0);
        } catch (Exception e) {
            return 0;
        }
    }

    public String getPhoneNumberByID(int id) {
        try {
            Cursor cursor = db.rawQuery("SELECT phone_number FROM " + USER_TABLE + " WHERE ID = ?", new String[] {String.valueOf(id)});
            cursor.moveToFirst();
            return cursor.getString(0);
        } catch (Exception e) {
            return "";
        }
    }

    public int getLastWeightInputByUserID(int id) {
        try {
            Cursor cursor = db.rawQuery("SELECT daily_weight FROM " + WEIGHT_LOG_TABLE + " WHERE USER_ID = ?", new String[] {String.valueOf(id)});
            cursor.moveToLast();
            return cursor.getInt(0);

        } catch (Exception e) {
            System.out.println("IN CATCH");
            return 0;
        }
    }

    public boolean userExists(String email, String password) {
        try {
            Cursor cursor = db.rawQuery("SELECT id FROM " + USER_TABLE + " WHERE EMAIL = ? AND PASSWORD = ?", new String[] {email, password});
            cursor.moveToFirst();
            return cursor.getInt(0) > 0 ? true : false;
        } catch (Exception e) {
            return false;
        }
    }

    public void insertLog(WeightLog weightLog) {
        ContentValues cv = new ContentValues();
        cv.put(DAILY_WEIGHT, weightLog.getDaily_weight());
        cv.put(USER_ID, weightLog.getUser_id());
        cv.put(DATE, weightLog.getDate());

        db.insert(WEIGHT_LOG_TABLE, null, cv);
    }

    public void insertNewUser(User user) {
        ContentValues cv = new ContentValues();
        cv.put(FIRST_NAME, user.getFirst_name());
        cv.put(LAST_NAME, user.getLast_name());
        cv.put(EMAIL, user.getEmail());
        cv.put(PASSWORD, user.getPassword());
        cv.put(GOAL_WEIGHT, user.getGoal_weight());
        cv.put(PHONE_NUMBER, user.getPhone_number());
        cv.put(NOTIFICATIONS, 0);

        db.insert(USER_TABLE, null, cv);
    }


    @SuppressLint("Range")
    public List<WeightLog> getAllWeightLogs(int userID) {
        List<WeightLog> weightLogList = new ArrayList<>();
        Cursor cur = null;
        db.beginTransaction();
        try {
            cur = db.query(WEIGHT_LOG_TABLE, null, "user_id = " + userID, null, null, null, null, null);
            if (cur != null) {
                if (cur.moveToFirst()) {
                    do {
                        WeightLog weightLog = new WeightLog();
                        weightLog.setId(cur.getInt(cur.getColumnIndex(ID)));
                        weightLog.setDaily_weight(cur.getInt(cur.getColumnIndex(DAILY_WEIGHT)));
                        weightLog.setUser_id(cur.getInt(cur.getColumnIndex(USER_ID)));
                        weightLog.setDate(cur.getString(cur.getColumnIndex(DATE)));
                        weightLogList.add(weightLog);
                    } while (cur.moveToNext());
                }
            }
        } finally {
            db.endTransaction();
            cur.close();
        }
        return weightLogList;
    }

    public void updateDailyWeight(int id, int weight) {
        if (weight > -1) {
            ContentValues cv = new ContentValues();
            cv.put(DAILY_WEIGHT, weight);
            db.update(WEIGHT_LOG_TABLE, cv, ID + "=?", new String[]{String.valueOf(id)});
        }
    }

    public void updateNotifications(int id, int notifications) {
        ContentValues cv = new ContentValues();
        cv.put(NOTIFICATIONS, notifications);
        db.update(USER_TABLE, cv, ID + "=?", new String[] {String.valueOf(id)});
    }

    public void updateDate(int id, String date) {
        if (date != null && date.matches("^\\d{2}-\\d{2}-\\d{4}$")) {
            ContentValues cv = new ContentValues();
            cv.put(DATE, date);
            db.update(WEIGHT_LOG_TABLE, cv, ID + "=?", new String[] {String.valueOf(id)});
        }
    }

    public void deleteWeightLog(int id) {
        db.delete(WEIGHT_LOG_TABLE, ID + "=?", new String[] {String.valueOf(id)});
    }
}
