package com.example.project2weighttrackingappv2;

import static com.example.project2weighttrackingappv2.R.id.view_page;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.project2weighttrackingappv2.model.User;
import com.example.project2weighttrackingappv2.utils.DatabaseHandler;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.tabs.TabLayout;

public class LoginActivity extends AppCompatActivity {
    TabLayout tabLayout;
    ViewPager viewPager;

    Button signUpButton;
    Button loginButton;

    EditText firstNameInput;
    EditText lastNameInput;
    EditText passwordInput;
    EditText goalWeightInput;

    private DatabaseHandler db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // sets up the 2 tab layout
        tabLayout = findViewById(R.id.tab_layout);
        viewPager = findViewById(view_page);

        // adds headers to tabs and correct display
        tabLayout.addTab(tabLayout.newTab().setText("Login"));
        tabLayout.addTab(tabLayout.newTab().setText("Sign Up"));
        tabLayout.setTabGravity(TabLayout.GRAVITY_FILL);

        final LoginAdapter adapter = new LoginAdapter(getSupportFragmentManager(), this,tabLayout.getTabCount());
        viewPager.setAdapter(adapter);

        // allows user to switch tab on swipe
        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));

        // opens database
        db = new DatabaseHandler(this);
        db.openDatabase();

        // this section could be used in the future to consolidate login and sign up screens
        signUpButton = findViewById(R.id.signUpButton);
        if (signUpButton != null) {
            signUpButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    User newUser = new User();
                    newUser.setFirst_name(firstNameInput.getText().toString());
                    newUser.setLast_name(lastNameInput.getText().toString());
                    newUser.setGoal_weight(Integer.parseInt(goalWeightInput.getText().toString()));
                    newUser.setPassword(passwordInput.getText().toString());
                    db.insertNewUser(newUser);
                }
            });
        }
        loginButton = findViewById(R.id.loginButton);
        if (loginButton != null) {
            loginButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    User newUser = new User();
                    newUser.setFirst_name(firstNameInput.getText().toString());
                    newUser.setLast_name(lastNameInput.getText().toString());
                    newUser.setGoal_weight(Integer.parseInt(goalWeightInput.getText().toString()));
                    newUser.setPassword(passwordInput.getText().toString());
                    db.insertNewUser(newUser);
                }
            });
        }
    }
}