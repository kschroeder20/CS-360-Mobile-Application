package com.example.project2weighttrackingappv2;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.example.project2weighttrackingappv2.utils.DatabaseHandler;

public class LoginTabFragment extends Fragment {
    Button loginButton;

    EditText passwordInput;
    EditText emailInput;

    TextView errorMessage;

    private DatabaseHandler db;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        ViewGroup root = (ViewGroup) inflater.inflate(R.layout.login_tab_fragment, container, false);
        // getActivity().deleteDatabase("weightLogListDatabase"); DO NOT UNCOMMENT IN PRODUCTION
        db = new DatabaseHandler(getActivity());
        db.openDatabase();

        loginButton = (Button) root.findViewById(R.id.loginButton);

        // input fields
        passwordInput = (EditText) root.findViewById(R.id.password);
        emailInput = (EditText) root.findViewById(R.id.email);

        // requirement warning text
        errorMessage = (TextView) root.findViewById(R.id.errorMessage);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Boolean validInput = true;

                errorMessage.setText("");
                errorMessage.setVisibility(View.INVISIBLE);

                // validate input fields
                if (passwordInput.getText().toString().matches("")) {
                    validInput = false;
                    errorMessage.setText("Password Required");
                    errorMessage.setVisibility(getView().VISIBLE);
                }
                if (emailInput.getText().toString().matches("")) {
                    validInput = false;
                    errorMessage.setText("Email Required");
                    errorMessage.setVisibility(getView().VISIBLE);
                }
                if (db.getUserIdByEmail(emailInput.getText().toString()) < 1) {
                    validInput = false;
                    errorMessage.setText("There is no account with this email address");
                    errorMessage.setVisibility(getView().VISIBLE);
                } else if (db.userExists(emailInput.getText().toString(), passwordInput.getText().toString()) == false) {
                    validInput = false;
                    errorMessage.setText("Invalid password");
                    errorMessage.setVisibility(getView().VISIBLE);
                }

                if (validInput == true) {
                    // send user to home page
                    Intent intent = new Intent(getActivity(), MainActivity.class);
                    Bundle b = new Bundle();
                    b.putInt("key", db.getUserIdByEmail(emailInput.getText().toString())); // get user id
                    intent.putExtras(b); // put user id to your next Intent
                    startActivity(intent);
                }
            }
        });
        return root;
    }
}
