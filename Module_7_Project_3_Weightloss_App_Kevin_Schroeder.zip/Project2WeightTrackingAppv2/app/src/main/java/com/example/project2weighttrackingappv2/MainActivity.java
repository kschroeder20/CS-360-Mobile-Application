package com.example.project2weighttrackingappv2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDialogFragment;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.AbsListView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.project2weighttrackingappv2.adapter.WeightLogAdapter;
import com.example.project2weighttrackingappv2.model.WeightLog;
import com.example.project2weighttrackingappv2.utils.DatabaseHandler;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

public class MainActivity extends AppCompatActivity implements DialogCloseListener {

    private RecyclerView logsRecyclerView;
    private WeightLogAdapter weightLogAdapter;
    private FloatingActionButton fab;

    private TextView header;
    private TextView goalHeader;
    private TextView goalProgress;

    private List<WeightLog> weightLogList;
    private DatabaseHandler db;

    private boolean notifications = false;

    private int userID;
    private int goalWeight;
    private int lastWeightInput;
    private String userFirstName;
    private String phoneNumber;

    private String GOAL_REACHED_NOTIFICATION = "Congratulations, you have reached your goal!";

    private static final int MY_PERMISSIONS_REQUEST_READ_CONTACTS = 123;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // open db
        db = new DatabaseHandler(this);
        db.openDatabase();

        // store weight logs
        weightLogList = new ArrayList<>();

        // get initial values from arguments
        Bundle b = getIntent().getExtras();
        userID = b.getInt("key");
        userFirstName = db.getUserNameByID(userID);
        goalWeight = db.getGoalWeightByID(userID);
        phoneNumber = db.getPhoneNumberByID(userID);

        // set main header
        header = findViewById(R.id.header);
        header.setText("Hello " + userFirstName.substring(0, 1).toUpperCase() + userFirstName.substring(1));

        // set goal weight header
        goalHeader = findViewById(R.id.goal);
        goalHeader.setText("Goal Weight: " + String.valueOf(goalWeight));

        // set up weight log recycler
        logsRecyclerView = findViewById(R.id.logItems);
        logsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        weightLogAdapter = new WeightLogAdapter(db,this);
        logsRecyclerView.setAdapter(weightLogAdapter);

        // initiate floating add button
        fab = findViewById(R.id.addButton);

        // asks user permission to send SMS notifications
        // does not run after user has answered
        requestSmsPermission(db.getPhoneNumberByID(userID), "", false);

        // add logs to home screen
        ItemTouchHelper itemTouchHelper = new ItemTouchHelper((new RecyclerItemTouchHelper((weightLogAdapter))));
        itemTouchHelper.attachToRecyclerView(logsRecyclerView);

        // Database hookup
        weightLogList = db.getAllWeightLogs(userID);
        Collections.reverse(weightLogList);
        weightLogAdapter.setWeightLogs(weightLogList);

        // set up click listener to add new log
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AddNewWeightLog.newInstance(userID).show(getSupportFragmentManager(), AddNewWeightLog.TAG);
            }
        });
    }
    @Override
    // closses add log dialog screen
    public void handleDialogClose(DialogInterface dialog) {
        weightLogList = db.getAllWeightLogs(userID);
        Collections.reverse(weightLogList);
        weightLogAdapter.setWeightLogs(weightLogList);
        weightLogAdapter.notifyDataSetChanged();
        updateProgressHeader();
    }

    public void updateProgressHeader() {
        lastWeightInput = db.getLastWeightInputByUserID(userID);
        goalProgress = findViewById(R.id.goalProgress);
        if (lastWeightInput > 0) {
            int progress = Math.abs(goalWeight - lastWeightInput);
            goalProgress.setText("Progress: " + String.valueOf(progress) + "lbs to Goal"); // update user progress
        }
        if (lastWeightInput == goalWeight) {
            requestSmsPermission(db.getPhoneNumberByID(userID), GOAL_REACHED_NOTIFICATION, true); // congradulate our users!
        }
    }

    private void requestSmsPermission(String phone, String message, boolean sendMessage) {
        // check permission is given
        if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            // request permission (see result in onRequestPermissionsResult() method)
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.SEND_SMS}, MY_PERMISSIONS_REQUEST_READ_CONTACTS);
        } else {
            // permission already granted run sms send
            if (sendMessage) {
                sendSms(phone, message);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_READ_CONTACTS: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // permission was granted
                    sendSms(phoneNumber, GOAL_REACHED_NOTIFICATION);
                } else {
                    // permission denied
                }
                return;
            }
        }
    }
    // sends sms message if user ops in
    private void sendSms(String phoneNumber, String message){
        SmsManager sms = SmsManager.getDefault();
        sms.sendTextMessage(phoneNumber, null, message, null, null);
    }
}