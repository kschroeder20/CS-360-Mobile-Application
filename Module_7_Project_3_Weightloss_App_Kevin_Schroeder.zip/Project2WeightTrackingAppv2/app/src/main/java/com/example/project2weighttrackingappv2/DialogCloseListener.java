package com.example.project2weighttrackingappv2;

import android.content.DialogInterface;

public interface DialogCloseListener {
    public void handleDialogClose(DialogInterface dialog);
}
