package com.example.project2weighttrackingappv2;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.project2weighttrackingappv2.model.User;
import com.example.project2weighttrackingappv2.model.WeightLog;
import com.example.project2weighttrackingappv2.utils.DatabaseHandler;

import java.time.LocalDate;

public class SignupTabFragment extends Fragment {
    Button signUpButton;

    EditText firstNameInput;
    EditText lastNameInput;
    EditText passwordInput;
    EditText initialWeightInput;
    EditText goalWeightInput;
    EditText emailInput;
    EditText phoneNumberInput;

    TextView firstNameRequired;
    TextView lastNameRequired;
    TextView emailRequired;
    TextView passwordRequired;
    TextView initialWeightRequired;
    TextView goalWeightRequired;
    TextView phoneNumberRequired;

    private DatabaseHandler db;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        ViewGroup root = (ViewGroup) inflater.inflate(R.layout.signup_tab_fragment, container, false);

        db = new DatabaseHandler(getActivity());
        db.openDatabase();

        signUpButton = (Button) root.findViewById(R.id.signUpButton);

        // input fields
        firstNameInput = (EditText) root.findViewById(R.id.firstName);
        lastNameInput = (EditText) root.findViewById(R.id.lastName);
        passwordInput = (EditText) root.findViewById(R.id.password);
        emailInput = (EditText) root.findViewById(R.id.email);
        phoneNumberInput = (EditText) root.findViewById(R.id.phoneNumber);
        initialWeightInput = (EditText) root.findViewById(R.id.initialWeight);
        goalWeightInput = (EditText) root.findViewById(R.id.goalWeight);

        // requirement warning text
        firstNameRequired = (TextView) root.findViewById(R.id.firstNameRequired);
        lastNameRequired = (TextView) root.findViewById(R.id.lastNameRequired);
        emailRequired = (TextView) root.findViewById(R.id.emailRequired);
        passwordRequired = (TextView) root.findViewById(R.id.passwordRequired);
        initialWeightRequired = (TextView) root.findViewById(R.id.initialWeightRequired);
        goalWeightRequired = (TextView) root.findViewById(R.id.goalWeightRequired);
        phoneNumberRequired = (TextView) root.findViewById(R.id.phoneNumberRequired);

        signUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Boolean validInput = true;
                User newUser = new User();
                WeightLog weightLog = new WeightLog();

                // hide all required warning fields
                firstNameRequired.setVisibility(getView().INVISIBLE);
                lastNameRequired.setVisibility(getView().INVISIBLE);
                passwordRequired.setVisibility(getView().INVISIBLE);
                emailRequired.setVisibility(getView().INVISIBLE);
                initialWeightRequired.setVisibility(getView().INVISIBLE);
                goalWeightRequired.setVisibility(getView().INVISIBLE);
                phoneNumberRequired.setVisibility(getView().INVISIBLE);

                // validate input that fields have values
                if (firstNameInput.getText().toString().matches("")) {
                    validInput = false;
                    firstNameRequired.setVisibility(getView().VISIBLE);
                }
                if (lastNameInput.getText().toString().matches("")) {
                    validInput = false;
                    lastNameRequired.setVisibility(getView().VISIBLE);
                }
                if (phoneNumberInput.getText().toString().matches("")) {
                    validInput = false;
                    phoneNumberRequired.setVisibility(getView().VISIBLE);
                }
                if (passwordInput.getText().toString().matches("")) {
                    validInput = false;
                    passwordRequired.setVisibility(getView().VISIBLE);
                }
                if (emailInput.getText().toString().matches("")) {
                    validInput = false;
                    emailRequired.setText("Email Required");
                    emailRequired.setVisibility(getView().VISIBLE);
                }
                if (db.getUserIdByEmail(emailInput.getText().toString()) > 0) {
                    validInput = false;
                    emailRequired.setText("This email already has an account");
                    emailRequired.setVisibility(getView().VISIBLE);
                }
                if (initialWeightInput.getText().toString().matches("")) {
                    validInput = false;
                    initialWeightRequired.setVisibility(getView().VISIBLE);
                }
                if (goalWeightInput.getText().toString().matches("")) {
                    validInput = false;
                    goalWeightRequired.setVisibility(getView().VISIBLE);
                }

                if (validInput == true) {
                    // build new user
                    newUser.setFirst_name(firstNameInput.getText().toString());
                    newUser.setLast_name(lastNameInput.getText().toString());
                    newUser.setGoal_weight(Integer.parseInt(goalWeightInput.getText().toString()));
                    newUser.setInitial_weight(Integer.parseInt(initialWeightInput.getText().toString()));
                    newUser.setPassword(passwordInput.getText().toString());
                    newUser.setEmail(emailInput.getText().toString());
                    newUser.setPhone_number(phoneNumberInput.getText().toString());
                    // save new user
                    db.insertNewUser(newUser);

                    // build first weight log
                    weightLog.setDaily_weight(Integer.parseInt(initialWeightInput.getText().toString()));
                    weightLog.setDate(LocalDate.now().toString());
                    weightLog.setUser_id(db.getUserIdByEmail(emailInput.getText().toString()));
                    // create first weight log
                    db.insertLog(weightLog);

                    Intent intent = new Intent(getActivity(), MainActivity.class);
                    Bundle b = new Bundle();
                    b.putInt("key", db.getUserIdByEmail(emailInput.getText().toString())); // get user id
                    intent.putExtras(b); // put user id to your next Intent
                    startActivity(intent);
                }
            }
        });
        return root;
    }
}
