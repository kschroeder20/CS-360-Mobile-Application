package com.example.project2weighttrackingappv2.model;

import java.util.Date;

public class WeightLog {
    private int id, user_id, daily_weight;
    private String date;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public int getDaily_weight() { return daily_weight; }

    public void setDaily_weight(int daily_weight) {
        this.daily_weight = daily_weight;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
