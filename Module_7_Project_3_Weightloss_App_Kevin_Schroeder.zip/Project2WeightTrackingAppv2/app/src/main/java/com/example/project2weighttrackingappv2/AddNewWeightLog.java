package com.example.project2weighttrackingappv2;

import android.app.Activity;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;

import com.example.project2weighttrackingappv2.model.WeightLog;
import com.example.project2weighttrackingappv2.utils.DatabaseHandler;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

public class AddNewWeightLog extends BottomSheetDialogFragment {

    public static final String TAG = "ActionBottomDialog";

    private EditText newWeight;
    private EditText newDate;
    private Button newWeightButton;
    private DatabaseHandler db;
    public int userID;
    // creates new weight log
    public static AddNewWeightLog newInstance(int userID) {
        AddNewWeightLog addNewWeightLog = new AddNewWeightLog();
        // Supply userID as an argument.
        Bundle args = new Bundle();
        args.putInt("userID", userID);
        addNewWeightLog.setArguments(args);
        return addNewWeightLog;
    }

    @Override
    // creates dialog screen
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStyle(STYLE_NORMAL, R.style.DialogStyle);
    }

    @Override
    // creates dialog window
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.new_log, container, false);
        getDialog().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        return view;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        newWeight = getView().findViewById(R.id.newWeight);
        newDate = getView().findViewById(R.id.newDate);
        newWeightButton = getView().findViewById(R.id.newWeightButton);

        db = new DatabaseHandler(getActivity());
        db.openDatabase();

        boolean isUpdate = false;
        final Bundle bundle = getArguments();

        int weight = bundle.getInt("daily_weight");
        userID = bundle.getInt("userID");

        if(getArguments() != null && bundle.getInt("id") > 0) {
            isUpdate = true;
            newWeight.setText(String.valueOf(weight));
        }
        newWeight.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                // disable/enable submit button
                if (charSequence.toString().equals("")) {
                    newWeightButton.setEnabled(false);
                    newWeightButton.setTextColor(Color.GRAY);
                } else {
                    newWeightButton.setEnabled(true);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        boolean finalIsUpdate = isUpdate;
        newWeightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String weight = newWeight.getText().toString();
                String date = newDate.getText().toString();
                // creates new weight log when submission button is clicked
                // attributes weight log ot user by user id
                if (finalIsUpdate) {
                    db.updateDailyWeight(bundle.getInt("id"), Integer.parseInt(weight));
                    db.updateDate(bundle.getInt("id"), date);
                } else {
                    WeightLog weightLog = new WeightLog();
                    weightLog.setDaily_weight(Integer.parseInt(weight));
                    weightLog.setDate(date);
                    weightLog.setUser_id(userID);
                    db.insertLog(weightLog);
                }
                dismiss();
            }
        });
    }
    @Override
    // cancels dialog box without doing anything
    public void onDismiss(DialogInterface dialog) {
        Activity activity = getActivity();
        if (activity instanceof DialogCloseListener) {
            ((DialogCloseListener)activity).handleDialogClose(dialog);
        }
    }
}
