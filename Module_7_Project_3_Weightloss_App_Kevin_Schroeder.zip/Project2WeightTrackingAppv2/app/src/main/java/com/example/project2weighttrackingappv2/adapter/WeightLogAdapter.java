package com.example.project2weighttrackingappv2.adapter;

import android.content.Context;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.project2weighttrackingappv2.AddNewWeightLog;
import com.example.project2weighttrackingappv2.MainActivity;
import com.example.project2weighttrackingappv2.R;
import com.example.project2weighttrackingappv2.model.WeightLog;
import com.example.project2weighttrackingappv2.utils.DatabaseHandler;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class WeightLogAdapter extends RecyclerView.Adapter<WeightLogAdapter.ViewHolder> {
    private List<WeightLog> weightLogList;
    private MainActivity activity;
    private DatabaseHandler db;

    public WeightLogAdapter(DatabaseHandler db, MainActivity activity) {
        this.db = db;
        this.activity = activity;
    }

    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.log_layout, parent, false);
        return new ViewHolder(itemView);
    }

    public void onBindViewHolder(ViewHolder holder, int position) {
        db.openDatabase();
        WeightLog log = weightLogList.get(position);
        holder.firstLine.setText(String.valueOf(log.getDaily_weight()) + " lbs");
        holder.secondLine.setText(String.valueOf(log.getDate()));
    }

    public int getItemCount() {
        return weightLogList.size();
    }

    public static String convertDateToString(Date date)
    {
        DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd");
        String strDate = dateFormat.format(date);  ;
        return strDate;
    }

    public void setWeightLogs(List<WeightLog> weightLogList) {
        this.weightLogList = weightLogList;
        notifyDataSetChanged();
    }

    public Context getContext() {
        return activity;
    }

    public void deleteItem(int position) {
        WeightLog item = weightLogList.get(position);
        db.deleteWeightLog(item.getId());
        weightLogList.remove(position);
        activity.updateProgressHeader();
        notifyItemRemoved(position);
    }

    public void setWeightLogList(List<WeightLog> weightLogList) {
        this.weightLogList = weightLogList;
    }

    public void editItem(int position) {
        WeightLog item = weightLogList.get(position);
        Bundle bundle = new Bundle();
        bundle.putInt("id", item.getId());
        bundle.putInt("daily_weight", item.getDaily_weight());
        bundle.putInt("user_id", item.getUser_id());
        bundle.putString("date", item.getDate());
        AddNewWeightLog fragment = new AddNewWeightLog();
        fragment.setArguments(bundle);
        activity.updateProgressHeader();
        fragment.show(activity.getSupportFragmentManager(), AddNewWeightLog.TAG);
    }

    public static class ViewHolder extends RecyclerView.ViewHolder{
        ImageView icon;
        TextView firstLine;
        TextView secondLine;
        ImageView editIcon;
        ImageView deleteIcon;

        ViewHolder(View view) {
            super(view);
            icon = view.findViewById(R.id.icon);
            firstLine = view.findViewById(R.id.firstLine);
            secondLine = view.findViewById(R.id.secondLine);
        }
    }

}
